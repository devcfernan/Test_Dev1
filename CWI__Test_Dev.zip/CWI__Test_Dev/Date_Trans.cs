﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CWI__Test_Dev
{
    class Date_Trans
    {
        //Data
        public DateTime Datapedido { get; set; }
        public string Data_Par { get; set; }

        //Operando
        public Char Oper_Par { get; set; }

        //Minutos
        public long Min_Par { get; set; }

        public string ChangeDate(string date, char op, long value)
        {
            string resultado = date;

            //Trata os formatos
            int ano = Convert.ToInt32(date.Substring(6, 4));
            int mes = Convert.ToInt32(date.Substring(3, 2));
            long dia = Convert.ToInt32(date.Substring(0, 2));
            long hora = Convert.ToInt32(date.Substring(11, 2));
            long minutos = Convert.ToInt32(date.Substring(14, 2));

            //Valida o operador
            if (op != '-' && op != '+')
                throw new Exception("Operando informado incorreto");
            if (value < 0)
                value = value * (-1);
            bool adicao = (op == '+');

            if (adicao)
            {
                minutos = minutos + value;
                hora = hora + (minutos / 60);
                dia = dia + (hora / 24);
            }
            else
            {
                minutos = minutos + value;
                hora = hora + (minutos / 60);
                dia = dia + (hora / 24);
            }

            bool mes_valido = false;

            int[] m30 = { 4, 6, 9, 11 };
            int[] m31 = { 1, 3, 5, 7, 8, 10, 12 };

            while (!mes_valido)
            {
                bool is30 = m30.Contains(mes);
                bool is31 = m31.Contains(mes);
                mes_valido = (dia <= 28 && mes == 2) || (dia <= 30 && is30) || (dia <= 31 && is31);
                if (!mes_valido)
                {
                }
            }
            resultado = dia.ToString("00") + "/" + mes.ToString("00") + "/" + ano + " " + (hora % 24).ToString("00") + ":" + (minutos % 60).ToString("00");
            return resultado;

        }
    }
}
