﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
  
namespace CWI__Test_Dev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Date_Trans dt1 = new Date_Trans();

            if (string.IsNullOrEmpty(txtData.Text))
            {
                MessageBox.Show("Informe uma data!");
                return;  
            }
               
            if (string.IsNullOrEmpty(txtMinutos.Text))
            {
                MessageBox.Show("Informe os minutos!");
                return;  
            }

            //Envia os dados para a classe
            dt1.Data_Par = txtData.Text;
            dt1.Oper_Par = Convert.ToChar(cbo_oper.SelectedItem);
            dt1.Min_Par = Convert.ToInt64(txtMinutos.Text);

            //Executa o método e exibe ao usuário
            label_result.Text = dt1.ChangeDate(dt1.Data_Par, dt1.Oper_Par, dt1.Min_Par);
            label_result.Visible = true;  
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
    }
}
